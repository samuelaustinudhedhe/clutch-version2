


<?php if (isset($component)) { $__componentOriginal91c821ac63991f310c0b8692f4f16f0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91c821ac63991f310c0b8692f4f16f0a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
    <?php if (isset($component)) { $__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu','data' => ['name' => 'Menu']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Menu']); ?>

        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'overview']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'overview']); ?>
            <svg aria-hidden="true"
                class="w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z"></path>
                <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z"></path>
            </svg>
            Overview
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'users','href' => ''.e(route('admin.users.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'users','href' => ''.e(route('admin.users.index')).'']); ?>
            <svg class="w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"
                viewBox="0 0 24 24">
                <path fill-rule="evenodd"
                    d="M4 4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H4Zm10 5a1 1 0 0 1 1-1h3a1 1 0 1 1 0 2h-3a1 1 0 0 1-1-1Zm0 3a1 1 0 0 1 1-1h3a1 1 0 1 1 0 2h-3a1 1 0 0 1-1-1Zm0 3a1 1 0 0 1 1-1h3a1 1 0 1 1 0 2h-3a1 1 0 0 1-1-1Zm-8-5a3 3 0 1 1 6 0 3 3 0 0 1-6 0Zm1.942 4a3 3 0 0 0-2.847 2.051l-.044.133-.004.012c-.042.126-.055.167-.042.195.006.013.02.023.038.039.032.025.08.064.146.155A1 1 0 0 0 6 17h6a1 1 0 0 0 .811-.415.713.713 0 0 1 .146-.155c.019-.016.031-.026.038-.04.014-.027 0-.068-.042-.194l-.004-.012-.044-.133A3 3 0 0 0 10.059 14H7.942Z"
                    clip-rule="evenodd" />
            </svg>

            Users
             <?php $__env->slot('items', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Unvirified','href' => '/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Unvirified','href' => '/']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Drivers','href' => '/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Drivers','href' => '/']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>

             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'vehicles','href' => ''.e(route('admin.vehicles.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'vehicles','href' => ''.e(route('admin.vehicles.index')).'']); ?>

            <svg class="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                <path fill-rule="evenodd" d="M4 4a1 1 0 0 1 1-1h1.5a1 1 0 0 1 .979.796L7.939 6H19a1 1 0 0 1 .979 1.204l-1.25 6a1 1 0 0 1-.979.796H9.605l.208 1H17a3 3 0 1 1-2.83 2h-2.34a3 3 0 1 1-4.009-1.76L5.686 5H5a1 1 0 0 1-1-1Z" clip-rule="evenodd"/>
              </svg>
              
            Vehicles
             <?php $__env->slot('items', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Pending','href' => '/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Pending','href' => '/']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Aproved','href' => '/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Aproved','href' => '/']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>

             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02)): ?>
<?php $attributes = $__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02; ?>
<?php unset($__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02)): ?>
<?php $component = $__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02; ?>
<?php unset($__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu','data' => ['name' => 'menu2','class' => 'pt-5 mt-5 space-y-2 border-t border-gray-200 dark:border-gray-700']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu2','class' => 'pt-5 mt-5 space-y-2 border-t border-gray-200 dark:border-gray-700']); ?>

        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'helpdesk','href' => '#']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'helpdesk','href' => '#']); ?>
            <svg aria-hidden="true"
                class="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M5 10V7.914a1 1 0 0 1 .293-.707l3.914-3.914A1 1 0 0 1 9.914 3H18a1 1 0 0 1 1 1v6M5 19v1a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-1M10 3v4a1 1 0 0 1-1 1H5m14 9.006h-.335a1.647 1.647 0 0 1-1.647-1.647v-1.706a1.647 1.647 0 0 1 1.647-1.647L19 12M5 12v5h1.375A1.626 1.626 0 0 0 8 15.375v-1.75A1.626 1.626 0 0 0 6.375 12H5Zm9 1.5v2a1.5 1.5 0 0 1-1.5 1.5v0a1.5 1.5 0 0 1-1.5-1.5v-2a1.5 1.5 0 0 1 1.5-1.5v0a1.5 1.5 0 0 1 1.5 1.5Z" />
            </svg>
            Help desk
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'Refunds','href' => '#']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Refunds','href' => '#']); ?>
            <svg aria-hidden="true"
                class="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M7 3a1 1 0 000 2h6a1 1 0 100-2H7zM4 7a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zM2 11a2 2 0 012-2h12a2 2 0 012 2v4a2 2 0 01-2 2H4a2 2 0 01-2-2v-4z">
                </path>
            </svg>

            Refunds
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'roles','href' => ''.e(route('admin.roles.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'roles','href' => ''.e(route('admin.roles.index')).'']); ?>
            <svg aria-hidden="true"
                class="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="m13.46 8.291 3.849-3.849a1.5 1.5 0 0 1 2.122 0l.127.127a1.5 1.5 0 0 1 0 2.122l-3.84 3.838a4 4 0 0 0-2.258-2.238Zm0 0a4 4 0 0 1 2.263 2.238l3.662-3.662a8.961 8.961 0 0 1 0 10.27l-3.676-3.676m-2.25-5.17 3.678-3.676a8.961 8.961 0 0 0-10.27 0l3.662 3.662a4 4 0 0 0-2.238 2.258L4.615 6.863a8.96 8.96 0 0 0 0 10.27l3.662-3.662a4 4 0 0 0 2.258 2.238l-3.672 3.676a8.96 8.96 0 0 0 10.27 0l-3.662-3.662a4.001 4.001 0 0 0 2.238-2.262m0 0 3.849 3.848a1.5 1.5 0 0 1 0 2.122l-.127.126a1.499 1.499 0 0 1-2.122 0l-3.838-3.838a4 4 0 0 0 2.238-2.258Zm.29-1.461a4 4 0 1 1-8 0 4 4 0 0 1 8 0Zm-7.718 1.471-3.84 3.838a1.5 1.5 0 0 0 0 2.122l.128.126a1.5 1.5 0 0 0 2.122 0l3.848-3.848a4 4 0 0 1-2.258-2.238Zm2.248-5.19L6.69 4.442a1.5 1.5 0 0 0-2.122 0l-.127.127a1.5 1.5 0 0 0 0 2.122l3.849 3.848a4 4 0 0 1 2.238-2.258Z" />
            </svg>

            Roles 

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'permissions','href' => ''.e(route('admin.permissions.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'permissions','href' => ''.e(route('admin.permissions.index')).'']); ?>
            <svg aria-hidden="true"
                class="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="m13.46 8.291 3.849-3.849a1.5 1.5 0 0 1 2.122 0l.127.127a1.5 1.5 0 0 1 0 2.122l-3.84 3.838a4 4 0 0 0-2.258-2.238Zm0 0a4 4 0 0 1 2.263 2.238l3.662-3.662a8.961 8.961 0 0 1 0 10.27l-3.676-3.676m-2.25-5.17 3.678-3.676a8.961 8.961 0 0 0-10.27 0l3.662 3.662a4 4 0 0 0-2.238 2.258L4.615 6.863a8.96 8.96 0 0 0 0 10.27l3.662-3.662a4 4 0 0 0 2.258 2.238l-3.672 3.676a8.96 8.96 0 0 0 10.27 0l-3.662-3.662a4.001 4.001 0 0 0 2.238-2.262m0 0 3.849 3.848a1.5 1.5 0 0 1 0 2.122l-.127.126a1.499 1.499 0 0 1-2.122 0l-3.838-3.838a4 4 0 0 0 2.238-2.258Zm.29-1.461a4 4 0 1 1-8 0 4 4 0 0 1 8 0Zm-7.718 1.471-3.84 3.838a1.5 1.5 0 0 0 0 2.122l.128.126a1.5 1.5 0 0 0 2.122 0l3.848-3.848a4 4 0 0 1-2.258-2.238Zm2.248-5.19L6.69 4.442a1.5 1.5 0 0 0-2.122 0l-.127.127a1.5 1.5 0 0 0 0 2.122l3.849 3.848a4 4 0 0 1 2.238-2.258Z" />
            </svg>

           Permissions

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02)): ?>
<?php $attributes = $__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02; ?>
<?php unset($__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02)): ?>
<?php $component = $__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02; ?>
<?php unset($__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91c821ac63991f310c0b8692f4f16f0a)): ?>
<?php $attributes = $__attributesOriginal91c821ac63991f310c0b8692f4f16f0a; ?>
<?php unset($__attributesOriginal91c821ac63991f310c0b8692f4f16f0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91c821ac63991f310c0b8692f4f16f0a)): ?>
<?php $component = $__componentOriginal91c821ac63991f310c0b8692f4f16f0a; ?>
<?php unset($__componentOriginal91c821ac63991f310c0b8692f4f16f0a); ?>
<?php endif; ?>
<?php /**PATH /home/clutch/public_build/resources/views/admin/partials/sidebar.blade.php ENDPATH**/ ?>