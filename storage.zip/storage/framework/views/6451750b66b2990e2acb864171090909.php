<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['disabled' => false, 'loadJS' => false, 'id' => 'date-callender', 'placeholder' => 'Select date', 'width' => 'w-full', 'title' => '', 'position' => '', 'format' => 'mm/dd/yyyy', 'autohide' => false, 'min' => '', 'max' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['disabled' => false, 'loadJS' => false, 'id' => 'date-callender', 'placeholder' => 'Select date', 'width' => 'w-full', 'title' => '', 'position' => '', 'format' => 'mm/dd/yyyy', 'autohide' => false, 'min' => '', 'max' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div <?php if($loadJS): ?> x-data="{ initDatepicker() { document.querySelectorAll('[datepicker]').forEach($datepickerEl => { Array.from($datepickerEl.attributes).forEach(attr => { if (attr.name.startsWith('wire:')) { $datepickerEl.addEventListener('hide', function() { $wire.set(`${attr.value}`, $datepickerEl.value); }); }  }); }); } }" <?php endif; ?> x-init="() => { setTimeout(() => { initDatepickers(); initDatepicker(); }, 500); }" class="relative <?php echo e($width); ?>">
    <div class="absolute inset-y-0 start-0 flex items-center ps-3.5 pointer-events-none">
        <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
            <path d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
        </svg>
    </div>
    <input <?php echo e($disabled ? 'disabled' : ''); ?> id="<?php echo e($id); ?>" type="text" datepicker datepicker-autohide datepicker-title="<?php echo e($title); ?>" datepicker-orientation="<?php echo e($position); ?>" datepicker-format="<?php echo e($format); ?>" <?php if($autohide): ?> datepicker-autohide <?php endif; ?> datepicker-max-date="<?php echo e($max); ?>" datepicker-min-date="<?php echo e($min); ?>" <?php echo e($attributes->merge(['class' => 'bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 pl-10 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500'])); ?> placeholder="<?php echo e($placeholder); ?>">
</div>

<?php /**PATH /home/clutch/public_build/resources/views/components/date.blade.php ENDPATH**/ ?>