
<section class="bg-white dark:bg-gray-900 lg:py-0 lg:flex" wire:loading.class="opacity-50 pointer-events-none">
    
    <div
        class="hidden relative w-full min-h-[650px] max-w-md p-12 lg:h-screen lg:block bg-gray-100 dark:bg-gray-800 text-gray-500 rounded-r-2xl">
        
        <div class="flex items-center justify-between mb-8 space-x-4">
            <a href="#" class="flex items-center text-2xl font-semibold">
                <img class="w-10 h-10 mr-2" src="<?php echo e(app_logo()); ?>" />
                <span class="text-xl font-semibold"><?php echo e(app_name()); ?></span>
            </a>
            
            <?php echo darkModeSwitch(); ?>
        </div>

        <ul class="space-y-8 relative z-10">
            
            <li class="flex items-center space-x-4">
                <div class="relative">
                    <div
                        class="w-10 h-10 flex items-center justify-center <?php echo e($currentStep >= 0 ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'); ?> rounded-full">
                        <svg class="w-5 h-5 <?php echo e($currentStep >= 0 ? 'text-white' : 'text-gray-600 dark:text-gray-300'); ?>"
                            fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m10.051 8.102-3.778.322-1.994 1.994a.94.94 0 0 0 .533 1.6l2.698.316m8.39 1.617-.322 3.78-1.994 1.994a.94.94 0 0 1-1.595-.533l-.4-2.652m8.166-11.174a1.366 1.366 0 0 0-1.12-1.12c-1.616-.279-4.906-.623-6.38.853-1.671 1.672-5.211 8.015-6.31 10.023a.932.932 0 0 0 .162 1.111l.828.835.833.832a.932.932 0 0 0 1.111.163c2.008-1.102 8.35-4.642 10.021-6.312 1.475-1.478 1.133-4.77.855-6.385Zm-2.961 3.722a1.88 1.88 0 1 1-3.76 0 1.88 1.88 0 0 1 3.76 0Z" />
                        </svg>
                    </div>
                    <div
                        class="absolute w-1 h-12 <?php echo e($currentStep >= 0 ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'); ?> left-1/2 transform -translate-x-1/2 top-full">
                    </div>
                </div>
                <div>
                    <p class="text-sm font-semibold">Get Started</p>
                    <p class="text-sm text-gray-600 dark:text-gray-400">Get up and running in 3 minutes </p>
                </div>
            </li>
            
            <li class="flex items-center space-x-4">
                <div class="relative">
                    <div
                        class="w-10 h-10 flex items-center justify-center <?php echo e($currentStep >= 1 ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'); ?> rounded-full">
                        <svg class="w-5 h-5 <?php echo e($currentStep >= 1 ? 'text-white' : 'text-gray-600 dark:text-gray-300'); ?>"
                            fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke="currentColor" stroke-linecap="square" stroke-linejoin="round" stroke-width="2"
                                d="M10 19H5a1 1 0 0 1-1-1v-1a3 3 0 0 1 3-3h2m10 1a3 3 0 0 1-3 3m3-3a3 3 0 0 0-3-3m3 3h1m-4 3a3 3 0 0 1-3-3m3 3v1m-3-4a3 3 0 0 1 3-3m-3 3h-1m4-3v-1m-2.121 1.879-.707-.707m5.656 5.656-.707-.707m-4.242 0-.707.707m5.656-5.656-.707.707M12 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                        </svg>
                    </div>
                    <div
                        class="absolute w-1 h-12 <?php echo e($currentStep >= 1 ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'); ?> left-1/2 transform -translate-x-1/2 top-full">
                    </div>
                </div>
                <div>
                    <p class="text-sm font-semibold">Your Goal</p>
                    <p class="text-sm text-gray-600 dark:text-gray-400">What do you want to do</p>
                </div>
            </li>
            
            <li class="flex items-center space-x-4">
                <div class="relative">
                    <div
                        class="w-10 h-10 flex items-center justify-center <?php echo e($currentStep >= 2 ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'); ?> rounded-full">
                        <svg class="w-5 h-5 <?php echo e($currentStep >= 2 ? 'text-white' : 'text-gray-600 dark:text-gray-300'); ?>"
                            fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M18 5V4a1 1 0 0 0-1-1H8.914a1 1 0 0 0-.707.293L4.293 7.207A1 1 0 0 0 4 7.914V20a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5M9 3v4a1 1 0 0 1-1 1H4m11.383.772 2.745 2.746m1.215-3.906a2.089 2.089 0 0 1 0 2.953l-6.65 6.646L9 17.95l.739-3.692 6.646-6.646a2.087 2.087 0 0 1 2.958 0Z" />
                        </svg>

                    </div>
                    <div
                        class="absolute w-1 h-12 <?php echo e($currentStep >= 2 ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'); ?> left-1/2 transform -translate-x-1/2 top-full">
                    </div>
                </div>
                <div>
                    <p class="text-sm font-semibold">Personal Details</p>
                    <p class="text-sm text-gray-600 dark:text-gray-400">Help us get to know you</p>
                </div>
            </li>
            
            <li class="flex items-center space-x-4">
                <div class="relative">
                    <div
                        class="w-10 h-10 flex items-center justify-center <?php echo e($currentStep >= 3 ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'); ?> rounded-full">
                        <svg class="w-5 h-5 <?php echo e($currentStep >= 3 ? 'text-white' : 'text-gray-600 dark:text-gray-300'); ?>"
                            fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M11.644 3.066a1 1 0 0 1 .712 0l7 2.666A1 1 0 0 1 20 6.68a17.694 17.694 0 0 1-2.023 7.98 17.406 17.406 0 0 1-5.402 6.158 1 1 0 0 1-1.15 0 17.405 17.405 0 0 1-5.403-6.157A17.695 17.695 0 0 1 4 6.68a1 1 0 0 1 .644-.949l7-2.666Zm4.014 7.187a1 1 0 0 0-1.316-1.506l-3.296 2.884-.839-.838a1 1 0 0 0-1.414 1.414l1.5 1.5a1 1 0 0 0 1.366.046l4-3.5Z"
                                clip-rule="evenodd" />
                        </svg>


                    </div>
                    <div
                        class="absolute w-1 h-12 <?php echo e($currentStep >= 3 ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'); ?> left-1/2 transform -translate-x-1/2 top-full">
                    </div>
                </div>
                <div>
                    <p class="text-sm font-semibold">Verification</p>
                    <p class="text-sm text-gray-600 dark:text-gray-400">Enter your verification code</p>
                </div>
            </li>
            
            <li class="flex items-center space-x-4">
                <div class="relative">
                    <div
                        class="w-10 h-10 flex items-center justify-center <?php echo e($currentStep >= 3 ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'); ?> rounded-full">
                        <svg class="w-5 h-5 <?php echo e($currentStep >= 3 ? 'text-white' : 'text-gray-600 dark:text-gray-300'); ?>"
                            fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0 0a8.949 8.949 0 0 0 4.951-1.488A3.987 3.987 0 0 0 13 16h-2a3.987 3.987 0 0 0-3.951 3.512A8.948 8.948 0 0 0 12 21Zm3-11a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                        </svg>

                    </div>
                    <div
                        class="absolute w-1 h-12 <?php echo e($currentStep >= 3 ? 'bg-blue-600' : 'bg-gray-300 dark:bg-gray-600'); ?> left-1/2 transform -translate-x-1/2 top-full">
                    </div>
                </div>
                <div>
                    <p class="text-sm font-semibold">KYC</p>
                    <p class="text-sm text-gray-600 dark:text-gray-400">Verify your Identity</p>
                </div>
            </li>
            <li class="flex items-center space-x-4">
                <div class="relative">
                    <div
                        class="w-10 h-10 flex items-center justify-center <?php echo e($currentStep >= 4 ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-600'); ?> rounded-full">
                        <svg class="w-5 h-5 <?php echo e($currentStep >= 4 ? 'text-white' : 'text-gray-600 dark:text-gray-300'); ?>"
                            fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M8.5 11.5 11 14l4-4m6 2a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                        </svg>
                    </div>
                </div>
                <div>
                    <p class="text-sm font-semibold">Welcome Aboard</p>
                    <p class="text-sm text-gray-600 dark:text-gray-400">All done</p>
                </div>
            </li>
        </ul>


        <div class="flex justify-between items-center mt-8 mb-12 absolute bottom-0">
            <a wire:click="skipOnboarding"
                class="text-sm text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-300 hover:cursor-pointer">&larr;
                Back to Dashboard</a>
        </div>
    </div>

    
    <div class="grid relative items-center h-screen mx-auto md:w-[46rem] min-h-[650px] px-4 md:px-8 xl:px-0">

        
        <div class="flex items-center justify-between absolute top-0 mb-8 mt-12 space-x-4 lg:hidden w-full">
            <a href="#" class="flex items-center text-2xl font-semibold">
                <img class="w-10 h-10 mr-2" src="<?php echo e(app_logo()); ?>" />
                <span class="text-gray-900 dark:text-white"><?php echo e(app_name()); ?></span>
            </a>
            <a wire:click="skipOnboarding"
                class="text-sm text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300 hover:cursor-pointer">
                < Back to Dashboard </a>

        </div>

        <div class="grid mx-auto w-full my-10">
            <h1 class="mb-6 text-2xl font-extrabold tracking-tight text-gray-800 leding-tight dark:text-white">
                <?php echo e($stepNames[$currentStep]); ?>

            </h1>
            
            <div class="h-[640px] overflow-y-auto px-2">

                <!--[if BLOCK]><![endif]--><?php switch($currentStep):
                    case (0): ?>
                        <?php echo $__env->make('user.onboarding.introduction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php break; ?>

                    <?php case (1): ?>
                        <?php echo $__env->make('user.onboarding.select-role', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php break; ?>

                    <?php case (2): ?>
                        <?php echo $__env->make('user.onboarding.personal-details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php break; ?>

                    <?php case (3): ?>
                        <?php echo $__env->make('user.onboarding.verification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php break; ?>

                    <?php case (4): ?>
                        <?php echo $__env->make('user.onboarding.kyc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php break; ?>

                    <?php default: ?>
                        <?php echo $__env->make('user.onboarding.completed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <?php if (isset($component)) { $__componentOriginal1ff42cfe8b6cca3ab6d58c1bb019048f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ff42cfe8b6cca3ab6d58c1bb019048f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.steps-navigation','data' => ['getStarted' => 'Begain Onboarding Now','submit' => 'Finished Onboarding','totalSteps' => $totalSteps,'currentStep' => $currentStep,'nextStepName' => $nextStepName,'prevStepName' => $prevStepName]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('steps-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['getStarted' => 'Begain Onboarding Now','submit' => 'Finished Onboarding','totalSteps' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalSteps),'currentStep' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($currentStep),'nextStepName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nextStepName),'prevStepName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($prevStepName)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ff42cfe8b6cca3ab6d58c1bb019048f)): ?>
<?php $attributes = $__attributesOriginal1ff42cfe8b6cca3ab6d58c1bb019048f; ?>
<?php unset($__attributesOriginal1ff42cfe8b6cca3ab6d58c1bb019048f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ff42cfe8b6cca3ab6d58c1bb019048f)): ?>
<?php $component = $__componentOriginal1ff42cfe8b6cca3ab6d58c1bb019048f; ?>
<?php unset($__componentOriginal1ff42cfe8b6cca3ab6d58c1bb019048f); ?>
<?php endif; ?>

            <!--[if BLOCK]><![endif]--><?php if($currentStep < 1): ?>
                <p class="mt-4 text-sm font-light text-gray-500 dark:text-gray-400">
                    Not read to onboard?
                    <a href="#" wire:click="skipOnboarding"
                        class="font-medium text-blue-600 hover:underline dark:text-blue-500">
                        Skip the Onboarding Process
                    </a>.
                </p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div>

        <div class="items-center justify-center w-full absolute bottom-0 right-5 left-5 md:w-[38rem] ">
            
            
        </div>
    </div>

</section>
<?php /**PATH /home/clutch/public_build/resources/views/user/onboarding/main.blade.php ENDPATH**/ ?>