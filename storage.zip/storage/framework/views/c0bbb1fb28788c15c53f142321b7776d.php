
<?php if (isset($component)) { $__componentOriginal91c821ac63991f310c0b8692f4f16f0a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91c821ac63991f310c0b8692f4f16f0a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu','data' => ['name' => 'Menu']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Menu']); ?>
        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'overview']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'overview']); ?>
            <svg aria-hidden="true"
                class="w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M10 6.025A7.5 7.5 0 1 0 17.975 14H10V6.025Z" />
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M13.5 3c-.169 0-.334.014-.5.025V11h7.975c.011-.166.025-.331.025-.5A7.5 7.5 0 0 0 13.5 3Z" />
            </svg>
            Overview
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
 
        
        <?php if(auth()->check() && (auth()->user()->can('add_vehicles') || (auth('admin')->check() && auth('admin')->user()->can('add_vehicles')) || auth()->user()->can('create_posts') || (auth('admin')->check() && auth('admin')->user()->can('create_posts')))): ?>
            <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'vehicles','href' => ''.e(route('user.vehicles.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'vehicles','href' => ''.e(route('user.vehicles.index')).'']); ?>
                <svg aria-hidden="true"
                    class="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white"
                    xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                        d="M9.143 4H4.857A.857.857 0 0 0 4 4.857v4.286c0 .473.384.857.857.857h4.286A.857.857 0 0 0 10 9.143V4.857A.857.857 0 0 0 9.143 4Zm10 0h-4.286a.857.857 0 0 0-.857.857v4.286c0 .473.384.857.857.857h4.286A.857.857 0 0 0 20 9.143V4.857A.857.857 0 0 0 19.143 4Zm-10 10H4.857a.857.857 0 0 0-.857.857v4.286c0 .473.384.857.857.857h4.286a.857.857 0 0 0 .857-.857v-4.286A.857.857 0 0 0 9.143 14Zm10 0h-4.286a.857.857 0 0 0-.857.857v4.286c0 .473.384.857.857.857h4.286a.857.857 0 0 0 .857-.857v-4.286a.857.857 0 0 0-.857-.857Z" />
                </svg>
                My Vehicles
                 <?php $__env->slot('items', null, []); ?> 
                    <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Rentals','href' => ''.e(route('user.vehicles.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Rentals','href' => ''.e(route('user.vehicles.index')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Trips','href' => ''.e(route('user.vehicles.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Trips','href' => ''.e(route('user.vehicles.index')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>

                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'trips','href' => ''.e(route('user.trips.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trips','href' => ''.e(route('user.trips.index')).'']); ?>
            <svg aria-hidden="true"
                class="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white"
                xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 15a6 6 0 1 0 0-12 6 6 0 0 0 0 12Zm0 0v6M9.5 9A2.5 2.5 0 0 1 12 6.5" />
            </svg>

            My Trips
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'Messages']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Messages']); ?>
            <svg aria-hidden="true"
                class="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M9 17h6l3 3v-3h2V9h-2M4 4h11v8H9l-3 3v-3H4V4Z" />
            </svg>
            <span class="flex-1 whitespace-nowrap">Messages</span>
            <span
                class="inline-flex justify-center items-center min-w-fit h-5 text-xs font-semibold rounded-full text-blue-800 bg-blue-100 dark:bg-blue-200 dark:text-blue-800">
                100
            </span>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'wallet','href' => ''.e(route('user.wallet.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'wallet','href' => ''.e(route('user.wallet.index')).'']); ?>
            <svg aria-hidden="true"
                class="flex-shrink-0 w-6 h-6 text-gray-500 transition duration-75 group-hover:text-gray-900 dark:text-gray-400 dark:group-hover:text-white"
                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M17 8H5m12 0a1 1 0 0 1 1 1v2.6M17 8l-4-4M5 8a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.6M5 8l4-4 4 4m6 4h-4a2 2 0 1 0 0 4h4a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1Z" />
            </svg>

            Wallet

             <?php $__env->slot('items', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Balance','href' => '/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Balance','href' => '/']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Invoice','href' => '/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Invoice','href' => '/']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Refunds','href' => '/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Refunds','href' => '/']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>

        
        

        
        <?php if (isset($component)) { $__componentOriginal1ec4952b9430d7784e88e0025e3cc888 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown','data' => ['name' => 'profile','href' => ''.e(route('user.profile.show')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'profile','href' => ''.e(route('user.profile.show')).'']); ?>
            <svg class="w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none"
                viewBox="0 0 24 24">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                    d="M15 9h3m-3 3h3m-3 3h3m-6 1c-.306-.613-.933-1-1.618-1H7.618c-.685 0-1.312.387-1.618 1M4 5h16a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Zm7 5a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z" />
            </svg>
            Profile

             <?php $__env->slot('items', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Edit Photo','href' => ''.e(route('user.profile.photo')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Edit Photo','href' => ''.e(route('user.profile.photo')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => 'Change Passwod','href' => ''.e(route('user.profile.password')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Change Passwod','href' => ''.e(route('user.profile.password')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala8a4a44a20afe285451d3fab992e393c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8a4a44a20afe285451d3fab992e393c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu-dropdown-item','data' => ['name' => '2AF','href' => ''.e(route('user.profile.2af')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu-dropdown-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => '2AF','href' => ''.e(route('user.profile.2af')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $attributes = $__attributesOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__attributesOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8a4a44a20afe285451d3fab992e393c)): ?>
<?php $component = $__componentOriginala8a4a44a20afe285451d3fab992e393c; ?>
<?php unset($__componentOriginala8a4a44a20afe285451d3fab992e393c); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $attributes = $__attributesOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__attributesOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888)): ?>
<?php $component = $__componentOriginal1ec4952b9430d7784e88e0025e3cc888; ?>
<?php unset($__componentOriginal1ec4952b9430d7784e88e0025e3cc888); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02)): ?>
<?php $attributes = $__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02; ?>
<?php unset($__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02)): ?>
<?php $component = $__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02; ?>
<?php unset($__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02); ?>
<?php endif; ?>

    
    <?php if (isset($component)) { $__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aside-menu','data' => ['name' => 'menu2','class' => 'pt-5 mt-5 space-y-2 border-t border-gray-200 dark:border-gray-700']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('aside-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu2','class' => 'pt-5 mt-5 space-y-2 border-t border-gray-200 dark:border-gray-700']); ?>

        
        

        
        

        
        
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02)): ?>
<?php $attributes = $__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02; ?>
<?php unset($__attributesOriginal6b28e68fff7efc84a15a4d6d4a3dab02); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02)): ?>
<?php $component = $__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02; ?>
<?php unset($__componentOriginal6b28e68fff7efc84a15a4d6d4a3dab02); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91c821ac63991f310c0b8692f4f16f0a)): ?>
<?php $attributes = $__attributesOriginal91c821ac63991f310c0b8692f4f16f0a; ?>
<?php unset($__attributesOriginal91c821ac63991f310c0b8692f4f16f0a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91c821ac63991f310c0b8692f4f16f0a)): ?>
<?php $component = $__componentOriginal91c821ac63991f310c0b8692f4f16f0a; ?>
<?php unset($__componentOriginal91c821ac63991f310c0b8692f4f16f0a); ?>
<?php endif; ?>
<?php /**PATH /home/clutch/public_build/resources/views/user/partials/sidebar.blade.php ENDPATH**/ ?>