

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'disabled' => false,
    'title' => '- Select an option -',
    'loadJS' => false,
    'defaultValue' => null,
    'selected' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'disabled' => false,
    'title' => '- Select an option -',
    'loadJS' => false,
    'defaultValue' => null,
    'selected' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<select 
    <?php if($loadJS === 'true' || $loadJS): ?> x-data="{setDefaultOption(){const selectElements=document.querySelectorAll('select[data-default-value]');selectElements.forEach(select=>{const defaultValue=select.getAttribute('data-default-value');Array.from(select.attributes).forEach(attr=>{if(attr.name.startsWith('wire:')){if(!$wire.get(`${attr.value}`)){if(defaultValue){$wire.set(`${attr.value}`,defaultValue);select.value=defaultValue;}else{let defaultOption=Array.from(select.options).find(option=>option.hasAttribute('selected'));if(defaultOption&&defaultOption.value){$wire.set(`${attr.value}`,defaultOption.value);select.value=defaultOption.value;}else{$wire.set(`${attr.value}`,select.value);}}}}});});}}" x-init="setDefaultOption()" <?php endif; ?>
    <?php echo e($disabled ? 'disabled' : ''); ?> title="<?php echo e($title ?? ''); ?>" data-default-value="<?php echo e($defaultValue ?? $selected); ?>"
    <?php echo e($attributes->merge(['class' => 'bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500'])); ?>>
    <!--[if BLOCK]><![endif]--><?php if($title): ?>
        <option disabled><?php echo e($title); ?></option>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php echo e($slot); ?>

</select>
<?php /**PATH /home/clutch/public_build/resources/views/components/select.blade.php ENDPATH**/ ?>