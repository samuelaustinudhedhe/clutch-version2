<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['href' => '', 'color' => 'blue', 'focus' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['href' => '', 'color' => 'blue', 'focus' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    if ($focus) {
        // $classes = "inline-flex items-center px-4 py-2 bg-$color-700 dark:bg-$color-200 border border-transparent rounded-md
    //             font-semibold text-xs text-white dark:text-$color-700 uppercase tracking-widest hover:bg-$color-600
    //             dark:hover:bg-white focus:bg-$color-600 dark:focus:bg-white active:bg-$color-900 dark:active:bg-$color-300
    //             focus:outline-none focus:ring-2 focus:ring-$color-500 focus:ring-offset-2 dark:focus:ring-offset-$color-700
    //             disabled:opacity-50 transition ease-in-out duration-150";

        $classes = "inline-flex items-center px-4 py-2 bg-$color-700 dark:bg-$color-700 border 
        border-transparent rounded-md font-semibold text-sm text-white dark:text-white tracking-widest 
        hover:bg-$color-600 dark:hover:bg-$color-600 focus:bg-$color-600 dark:focus:bg-$color-600 
        active:bg-$color-900 dark:active:bg-$color-900 focus:outline-none focus:ring-2 focus:ring-$color-500 
        focus:ring-offset-2 dark:focus:ring-offset-$color-700 disabled:opacity-50 transition ease-in-out duration-150";
    } else {
        $classes = "inline-flex items-center rounded-md bg-$color-600 dark:bg-$color-600 
        px-4 py-2 text-sm font-semibold text-white dark:text-white shadow-sm hover:bg-$color-500 
        dark:hover:bg-$color-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 
        focus-visible:outline-$color-600";
    }
?>

<button <?php if($href): ?> onclick="window.location.href='<?php echo e($href); ?>'" <?php endif; ?>
    <?php echo e($attributes->merge(['type' => 'submit', 'class' => $classes])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/clutch/public_build/resources/views/components/button.blade.php ENDPATH**/ ?>