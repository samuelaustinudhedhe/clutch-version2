<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'items', 'href' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'items', 'href' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<li name="<?php echo e($name ?? 'nav'); ?>" x-data="{ open: false }">
    <!--[if BLOCK]><![endif]--><?php if(!empty($items)): ?>
        <div <?php echo e($attributes->merge(['class' => 'flex items-center space-between p-2 w-full text-base font-medium text-gray-900 rounded-lg transition duration-75 group hover:bg-gray-100 dark:text-white dark:hover:bg-gray-700'])); ?>>
            <a  <?php if(!empty($href)): ?> href="<?php echo e($href); ?>" <?php endif; ?> class="flex w-full text-left whitespace-nowrap gap-x-3">
                <?php echo e($slot); ?>

            </a>
            <button type="button" @click="open = !open" class="pl-5" aria-controls="dropdown-<?php echo e($name); ?>"
                :aria-expanded="open" data-collapse-toggle="dropdown-<?php echo e($name); ?>">
                <svg aria-hidden="true" :class="{ 'rotate-90': open }" class="w-6 h-6 transition-transform transform"
                    fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                        clip-rule="evenodd"></path>
                </svg>
            </button>
        </div>
        <ul x-show="open" id="dropdown-<?php echo e($name); ?>" class="py-2 space-y-2">
            <?php echo e($items ?? $item); ?>

        </ul>
    <?php else: ?>
        <a <?php if(!empty($href)): ?> href="<?php echo e($href); ?>" <?php endif; ?>   <?php echo e($attributes->merge(['class' => 'flex items-center p-2 text-base font-medium text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group gap-x-3'])); ?>>
            <?php echo e($slot); ?>

        </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</li><?php /**PATH /home/clutch/public_build/resources/views/components/aside-menu-dropdown.blade.php ENDPATH**/ ?>