<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'nextPrefix' => 'Next:',
    'prevPrefix' => 'Prev:',
    'submit' => 'Submit',
    'currentStep' => 1,
    'totalSteps' => 5,
    'nextStepName' => null,
    'prevStepName' => null,
    'getStarted' => 'Get Started',
    'nextClass' => '',
    'prevClass' => '',
    'submitClass' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'nextPrefix' => 'Next:',
    'prevPrefix' => 'Prev:',
    'submit' => 'Submit',
    'currentStep' => 1,
    'totalSteps' => 5,
    'nextStepName' => null,
    'prevStepName' => null,
    'getStarted' => 'Get Started',
    'nextClass' => '',
    'prevClass' => '',
    'submitClass' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>


<div <?php echo e($attributes->merge(['class' => 'flex justify-between mt-16 mb-6 space-x-3'])); ?>>
    <!--[if BLOCK]><![endif]--><?php if($currentStep > 1): ?>
        <a href="#" wire:click.prevent="prevStep" wire:loading.attr="disabled" type="button"
            class="text-center items-center w-full py-2.5 sm:py-3.5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-200 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 <?php echo e($prevClass); ?>">
            <?php echo e($prevPrefix ? $prevPrefix . ' ' : ''); ?> <?php echo e($prevStepName ?? ''); ?>

        </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($currentStep < $totalSteps): ?>
        <button type="button" wire:click.prevent="nextStep" wire:loading.attr="disabled"
            class="w-full text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 sm:py-3.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 <?php echo e($nextClass); ?>">
            <!--[if BLOCK]><![endif]--><?php if($currentStep < 1): ?>
                <?php echo e($getStarted); ?>

            <?php else: ?>
                <?php echo e($nextPrefix ? $nextPrefix . ' ' : ''); ?><?php echo e($nextStepName ?? ''); ?>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </button>
    <?php else: ?>
        <button type="submit" wire:click="submit" wire:loading.attr="disabled"
            class="w-full text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 sm:py-3.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800 <?php echo e($submitClass); ?>">
            <?php echo e($submit ?? 'Submit'); ?>

        </button>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH /home/clutch/public_build/resources/views/components/steps-navigation.blade.php ENDPATH**/ ?>