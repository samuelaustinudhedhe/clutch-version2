<div>



    <div class="flex items-center justify-center mt-20">
        <div class="grid space-y-6 text-center">
            <img src="/assets/images/placeholders/985e307e72.png" alt="Placeholder Image"
                class="mx-auto max-w-[200px] min-w-[150px]">
            <p class="text-gray-600 mt-8 dark:text-gray-300"> Welcome to Admin Vehicle Wizard .</p>


        </div>
    </div>

    

</div>
<?php /**PATH /home/clutch/public_build/resources/views/resources/vehicles/wizard/introduction.blade.php ENDPATH**/ ?>