

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'disabled' => false,
    'id' => 'address',
    'label' => '',
    'labelClass' => '',
    'errorClass' => '',
    'address' => 'address',
    'loadJS' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'disabled' => false,
    'id' => 'address',
    'label' => '',
    'labelClass' => '',
    'errorClass' => '',
    'address' => 'address',
    'loadJS' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="mb-4" <?php if($loadJS == true): ?> 
    x-data="{initAddressAutocomplete(input){const existingPacContainers=document.querySelectorAll('.pac-container');existingPacContainers.forEach(container=>container.remove());const autocomplete=new google.maps.places.Autocomplete(input);autocomplete.setOptions({types:['geocode'],strictBounds:false});autocomplete.addListener('place_changed',()=>{const place=autocomplete.getPlace();this.handlePlaceChange(place,input);});input.addEventListener('blur',async()=>{const inputValue=input.value;if(inputValue&&!autocomplete.getPlace()){const geocoder=new google.maps.Geocoder();const result=await this.geocodeAddress(geocoder,inputValue);if(result){this.handlePlaceChange(result,input);}}this.closeSuggestionBox();});input.addEventListener('focusout',()=>{this.closeSuggestionBox();});},closeSuggestionBox(){const pacContainer=document.querySelector('.pac-container');if(pacContainer){pacContainer.style.display='none';}},async geocodeAddress(geocoder,address){return new Promise((resolve,reject)=>{geocoder.geocode({'address':address},(results,status)=>{if(status==='OK'&&results[0]){resolve(results[0]);$wire.dispatch('notify',{message:'Your location is on the map',type:'success'});}else{$wire.dispatch('notify',{message:'Your location is not found on the map. (Code: 29-023_L)',type:'error'});}});});},handlePlaceChange(place,input){let street,city,state,country,postal_code,latitude,longitude;if(place.address_components){place.address_components.forEach(component=>{const addressType=component.types[0];const longName=component.long_name;switch(addressType){case'street_number':street=longName+' '+street;break;case'route':street+=longName;break;case'locality':case'sublocality_level_1':city=longName;break;case'administrative_area_level_1':state=component.short_name;break;case'country':country=longName;break;case'postal_code':postal_code=longName;break;}});}if(place.geometry){latitude=place.geometry.location.lat();longitude=place.geometry.location.lng();}if(street&&city&&state&&country){const address={street,city,state,country,postal_code,latitude,longitude};console.log('Extracted address:',address);Array.from(input.attributes).forEach(attr=>{if(attr.name.startsWith('wire:')){const strippedValue=attr.value.replace('.full','');$wire.set(`${strippedValue}`,address);}});const event=new Event('input',{bubbles:true,cancelable:true});input.dispatchEvent(event);}else{$wire.dispatch('notify',{message:'There seems to be an issue with the address provided. Kindly use the suggestion box and enter your complete address. (Code: 30-023_L)',type:'error'});}}}" 
    <?php endif; ?>>
    <label class="block font-medium text-sm text-gray-700 dark:text-gray-300 mb-1 <?php echo e($labelClass); ?>" for="<?php echo e($id); ?>">
        <?php echo e($label); ?>

    </label>
    <input <?php echo e($disabled ? 'disabled' : ''); ?> <?php echo $attributes->merge([
        'class' => 'bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg 
                    focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 
                    dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500',
    ]); ?> address="<?php echo e($address); ?>" autocomplete="off" @focus="initAddressAutocomplete($el)">

    <?php $__errorArgs = [$id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-sm text-red-600 dark:text-red-400 <?php echo e($errorClass); ?>"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH /home/clutch/public_build/resources/views/components/location.blade.php ENDPATH**/ ?>