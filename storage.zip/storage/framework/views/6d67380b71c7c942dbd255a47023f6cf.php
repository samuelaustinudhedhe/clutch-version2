<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['id', 'taClass' => 'bg-white dark:bg-gray-800', 'icon' => false, 'trigger' => 'hover']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['id', 'taClass' => 'bg-white dark:bg-gray-800', 'icon' => false, 'trigger' => 'hover']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => 'flex items-center gap-1 group'])); ?> x-init="initTooltips()"
    <?php if(!$icon): ?> data-tooltip-target="<?php echo e($id); ?>-tooltip" data-tooltip-trigger="<?php echo e($trigger); ?>"  <?php endif; ?>>
    <?php echo e($trigger); ?>

    <!--[if BLOCK]><![endif]--><?php if($icon): ?>
        <svg class="h-4 w-4 text-gray-400 hover:text-gray-900 dark:text-gray-500 dark:hover:text-white" aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg" width="24" height="24"fill="currentColor" data-tooltip-target="<?php echo e($id); ?>-tooltip"  data-tooltip-trigger="<?php echo e($trigger); ?>" viewBox="0 0 24 24">
            <path fill-rule="evenodd"
                d="M2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10S2 17.523 2 12Zm9.408-5.5a1 1 0 1 0 0 2h.01a1 1 0 1 0 0-2h-.01ZM10 10a1 1 0 1 0 0 2h1v3h-1a1 1 0 1 0 0 2h4a1 1 0 1 0 0-2h-1v-4a1 1 0 0 0-1-1h-2Z"
                clip-rule="evenodd" />
        </svg>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>

<div id="<?php echo e($id); ?>-tooltip" role="tooltip"
    class="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-gray-600 dark:text-white transition-opacity duration-300  border border-gray-200/[.55] dark:border-gray-500/[.55] rounded-lg shadow-sm opacity-0 tooltip <?php echo e($taClass); ?>">
    <?php echo e($content); ?>

    <div class="tooltip-arrow <?php echo e($taClass); ?>" data-popper-arrow=""></div>
</div>
<?php /**PATH /home/clutch/public_build/resources/views/components/tooltip.blade.php ENDPATH**/ ?>