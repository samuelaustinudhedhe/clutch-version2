<ul <?php echo e($attributes->merge(['name'=>'Menu', 'class'=>'space-y-2'])); ?>>
    <?php echo e($slot); ?>

</ul><?php /**PATH /home/clutch/public_build/resources/views/components/aside-menu.blade.php ENDPATH**/ ?>