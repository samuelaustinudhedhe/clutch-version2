
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['id', 'class' => '', 'color' => 'blue', 'showIcon' => 'true']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['id', 'class' => '', 'color' => 'blue', 'showIcon' => 'true']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div>
    <input type="radio" id="<?php echo e($id); ?>" <?php echo e($attributes); ?> class="hidden peer">
    <label for="<?php echo e($id); ?>" class="inline-flex items-center justify-center w-full p-5 text-gray-500 border-2 border-gray-200 rounded-lg cursor-pointer dark:hover:text-gray-300 dark:border-gray-700 dark:peer-checked:text-<?php echo e($color); ?>-500 peer-checked:border-<?php echo e($color); ?>-600 peer-checked:text-<?php echo e($color); ?>-600 bg-gray-50 hover:text-gray-600 hover:bg-gray-100 dark:text-gray-400 dark:bg-gray-800 dark:hover:bg-gray-700 <?php echo e($class); ?>">
        <?php echo e($slot); ?>

        <!--[if BLOCK]><![endif]--><?php if($showIcon === 'true'): ?>
            <svg class="w-6 h-6 ml-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd"></path>
            </svg> 
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </label>
</div><?php /**PATH /home/clutch/public_build/resources/views/components/radio.blade.php ENDPATH**/ ?>