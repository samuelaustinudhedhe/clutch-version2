

<div <?php echo e($attributes->merge(['class' => 'rounded-lg border border-gray-200 dark:border-gray-700 bg-white p-4 shadow-sm dark:bg-gray-800 sm:p-6 my-4'])); ?>>
    <?php echo e($slot); ?>

</div>

<?php /**PATH /home/clutch/public_build/resources/views/components/div.blade.php ENDPATH**/ ?>