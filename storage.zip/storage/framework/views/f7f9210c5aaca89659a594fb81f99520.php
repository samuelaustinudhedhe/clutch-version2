<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['disabled' => false, 'id' => '','iclass' => 'w-5 h-5', 'color' => 'blue']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['disabled' => false, 'id' => '','iclass' => 'w-5 h-5', 'color' => 'blue']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<label for="<?php echo e($id); ?>" class="sr-only">Search</label>
<div class="relative w-full">
    <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
        <svg aria-hidden="true" class="<?php echo e($iclass); ?> text-gray-500 dark:text-gray-400" fill="currentColor" viewbox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd"
                d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" />
        </svg>
    </div>
    <input id="<?php echo e($id); ?>" <?php echo e($attributes->merge([
            'class' => "bg-gray-50 border border-gray-300 text-gray-900 text-sm
                 rounded-lg focus:ring-$color-500 focus:border-$color-500 block w-full pl-10 p-2.5 dark:bg-gray-700 
                 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-$color-500 dark:focus:border-$color-500",
                 'placeholder' => "Search..."
        ])); ?> <?php echo e($disabled ? 'disabled' : ''); ?> />
</div>
<?php /**PATH /home/clutch/public_build/resources/views/components/search.blade.php ENDPATH**/ ?>