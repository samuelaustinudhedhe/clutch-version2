<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['color'=>'blue', 'name' => '', 'size' => '', 'weight' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['color'=>'blue', 'name' => '', 'size' => '', 'weight' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<a title="<?php echo e($name); ?>" <?php echo e($attributes->merge(['class'=>'inline-flex items-center gap-1 text-sm font-' . $weight . ' text-' . $color . '-500 no-underline hover:underline hover:text-' . $color . '-600 dark:text-' . $color . '-400 dark:hover:text-' . $color . '-300'])); ?>>
    <?php echo e($slot); ?>

</a><?php /**PATH /home/clutch/public_build/resources/views/components/a.blade.php ENDPATH**/ ?>