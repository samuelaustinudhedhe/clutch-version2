<div x-data="{
    handleScroll(e) {
        e.preventDefault();
        this.$el.scrollLeft += e.deltaY;
    }
}" x-on:wheel.prevent="handleScroll" x-on:mousewheel.prevent="handleScroll"
    class="flex overflow-x-auto overflow-hidden gap-4 h-[72px] min-h-[72px] pt-4 mx-4 2xl:ml-0 filters-scrollbar">
    <div class="relative min-w-[220px] w-[320px] max-h-[40px] ">
        <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <svg aria-hidden="true" class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="currentColor" viewbox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                    clip-rule="evenodd" />
            </svg>
        </div>
        <?php if (isset($component)) { $__componentOriginalb1fd1993764f844f04f080855cb8362a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1fd1993764f844f04f080855cb8362a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.xinput','data' => ['type' => 'text','wire:model.live' => 'search','id' => 'simple-search','class' => 'block w-full p-2 py-2 pl-10 text-sm h-[40px] ','placeholder' => 'Search','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('xinput'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','wire:model.live' => 'search','id' => 'simple-search','class' => 'block w-full p-2 py-2 pl-10 text-sm h-[40px] ','placeholder' => 'Search','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1fd1993764f844f04f080855cb8362a)): ?>
<?php $attributes = $__attributesOriginalb1fd1993764f844f04f080855cb8362a; ?>
<?php unset($__attributesOriginalb1fd1993764f844f04f080855cb8362a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1fd1993764f844f04f080855cb8362a)): ?>
<?php $component = $__componentOriginalb1fd1993764f844f04f080855cb8362a; ?>
<?php unset($__componentOriginalb1fd1993764f844f04f080855cb8362a); ?>
<?php endif; ?>
    </div>

    <!--[if BLOCK]><![endif]--><?php if(isset($makesAndModels)): ?>
        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['id' => 'make','wire:model.live' => 'filterBy.make','title' => '','loadJS' => 'true','class' => 'h-[40px] min-w-[180px] w-[180px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'make','wire:model.live' => 'filterBy.make','title' => '','loadJS' => 'true','class' => 'h-[40px] min-w-[180px] w-[180px]']); ?>
            <option value="">Select Manufacturer</option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $makesAndModels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make => $models): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($make); ?>"><?php echo e($make); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if(isset($makesAndModels) && !empty($filterBy['make'])): ?>

        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['id' => 'model','wire:model' => 'filterBy.model','title' => '','loadJS' => 'true','class' => 'h-[40px] min-w-[140px] w-[140px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'model','wire:model' => 'filterBy.model','title' => '','loadJS' => 'true','class' => 'h-[40px] min-w-[140px] w-[140px]']); ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $makesAndModels[$filterBy['make']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($model); ?>"><?php echo e($model); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['id' => 'year','wire:model.live' => 'filterBy.year','title' => '','loadJS' => 'true','class' => 'h-[40px] min-w-[120px] w-[120px]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'year','wire:model.live' => 'filterBy.year','title' => '','loadJS' => 'true','class' => 'h-[40px] min-w-[120px] w-[120px]']); ?>
        <option value="">Select Year</option>
        <!--[if BLOCK]><![endif]--><?php for($year = date('Y') + 1; $year >= 1900; $year--): ?>
            <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
        <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
</div>



<?php /**PATH /home/clutch/public_build/resources/views/pages/vehicles/index/filters.blade.php ENDPATH**/ ?>