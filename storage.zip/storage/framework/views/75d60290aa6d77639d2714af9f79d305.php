
<div>

    <?php if (isset($component)) { $__componentOriginal3f00ccaefd3b3202e8ec6f52d3527ea0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f00ccaefd3b3202e8ec6f52d3527ea0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.div','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('div'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <p class="mb-2 text-lg font-extrabold tracking-tight text-gray-900 leding-tight dark:text-white">Verify your
            email
            address</p>
        <!--[if BLOCK]><![endif]--><?php if(Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::emailVerification()) && !$this->user->hasVerifiedEmail()): ?>
            <p class="text-sm font-light text-gray-500 dark:text-gray-400">We emailed you a verification link to <span
                    class="font-medium text-gray-900 dark:text-white"><?php echo e($user->email ?? 'your email'); ?></span>.
                click on it to confirm your email address.</p>
                <p class="text-sm mt-2 dark:text-white">
                    <?php echo e(__('Your email address is unverified.')); ?>


                    <button type="button"
                        class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
                        wire:click.prevent="sendEmailVerification">
                        <?php echo e(__('Click here to re-send the verification email.')); ?>

                    </button>
                </p>

                <!--[if BLOCK]><![endif]--><?php if($this->verificationLinkSent): ?>
                    <p class="mt-2 font-medium text-sm text-green-600 dark:text-green-400">
                        <?php echo e(__('A new verification link has been sent to your email address.')); ?>

                    </p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->        
                
        <?php else: ?>
        <p class="text-sm font-light text-gray-500 dark:text-gray-400">Your email address <span
            class="font-medium text-green-800 dark:text-green-100"><?php echo e($user->email ?? ''); ?></span> is verified.</p>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f00ccaefd3b3202e8ec6f52d3527ea0)): ?>
<?php $attributes = $__attributesOriginal3f00ccaefd3b3202e8ec6f52d3527ea0; ?>
<?php unset($__attributesOriginal3f00ccaefd3b3202e8ec6f52d3527ea0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f00ccaefd3b3202e8ec6f52d3527ea0)): ?>
<?php $component = $__componentOriginal3f00ccaefd3b3202e8ec6f52d3527ea0; ?>
<?php unset($__componentOriginal3f00ccaefd3b3202e8ec6f52d3527ea0); ?>
<?php endif; ?>
    

</div>
<?php /**PATH /home/clutch/public_build/resources/views/user/onboarding/verification.blade.php ENDPATH**/ ?>