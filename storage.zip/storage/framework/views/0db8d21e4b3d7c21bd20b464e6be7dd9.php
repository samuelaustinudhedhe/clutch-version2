<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['id','name' => 'Accordion item', 'divClass' => '', 'customIcon' => false, 'expanded' => 'true']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['id','name' => 'Accordion item', 'divClass' => '', 'customIcon' => false, 'expanded' => 'true']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $divClass = $divClass? $divClass : 'rounded-lg border border-gray-200 bg-white shadow-sm dark:border-gray-700 dark:bg-gray-800 my-4';
?>

<div class="relative <?php echo e($divClass); ?>">

<button  id="<?php echo e($id); ?>-title" title="<?php echo e($name); ?>" type="button" class="flex items-center justify-between w-full p-4 sm:p-6 bg-unset"
    data-accordion-target="#<?php echo e($id); ?>-content" aria-expanded="<?php echo e($expanded); ?>" aria-controls="<?php echo e($id); ?>-content">

    <?php echo e($title); ?>


    <!--[if BLOCK]><![endif]--><?php if(!$customIcon): ?>
        <svg data-accordion-icon class="w-3 h-3 rotate-180 shrink-0" aria-hidden="false" xmlns="http://www.w3.org/2000/svg"
            fill="none" viewBox="0 0 10 6">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M9 5 5 1 1 5" />
        </svg>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</button>
<div id="<?php echo e($id); ?>-content" class="<?php echo e(($expanded === 'true' || $expanded === true) ? '' : 'hidden'); ?> p-4 !pt-0 sm:p-6 " aria-labelledby="<?php echo e($id); ?>-title">
    <?php echo e($content ?? $slot); ?>

</div>
</div>
<?php /**PATH /home/clutch/public_build/resources/views/components/accordion-item.blade.php ENDPATH**/ ?>