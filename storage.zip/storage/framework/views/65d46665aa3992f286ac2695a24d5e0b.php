<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['id', 'activeClass' => '', 'inactiveClass' => '', 'class' => '', 'accordion' => 'collapse']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['id', 'activeClass' => '', 'inactiveClass' => '', 'class' => '', 'accordion' => 'collapse']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $class = $class
        ? $class
        : 'rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-gray-800 sm:p-6 my-4';
?>


<div id="<?php echo e($id); ?>" data-accordion="<?php echo e($accordion); ?>" data-active-classes="<?php echo e($activeClass); ?>"
    data-inactive-classes="<?php echo e($inactiveClass); ?>" <?php echo e($attributes->merge(['class' => $class])); ?>>
    <?php echo e($slot); ?>

</div>

<?php /**PATH /home/clutch/public_build/resources/views/components/accordion.blade.php ENDPATH**/ ?>