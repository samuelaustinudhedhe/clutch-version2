
<footer
    class="bg-white border-t border-gray-200 dark:border-gray-700 shadow sm:flex sm:items-center sm:justify-between p-4 sm:p-6 xl:p-8 dark:bg-gray-800 antialiased">
    <p class="mb-4 text-sm text-center text-gray-500 dark:text-gray-400 sm:mb-0">
        &copy; <?php echo e(date('Y')); ?><a href="<?php echo e(app_url()); ?>" class="hover:underline"
            target="_blank"><?php echo e(app_name()); ?></a>. All
        rights reserved.
    </p>
    <div class="flex justify-center items-center space-x-1">

    </div>
</footer>
<?php /**PATH /home/clutch/public_build/resources/views/admin/partials/footer.blade.php ENDPATH**/ ?>