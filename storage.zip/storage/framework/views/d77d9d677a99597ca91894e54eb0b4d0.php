<div class="text-center">
    <h1 class="mb-4 text-4xl font-extrabold leading-tight tracking-tight text-gray-900 sm:mb-6 dark:text-white">
        Welcome to clutch</h1>

    <p class="mb-4 text-lg font-light text-gray-300 dark:text-gray-400">We're thrilled to have you with us.</p>
    <p class="text-lg font-light text-gray-300 dark:text-gray-400">In just 3 minutes, you'll be fully set up and ready to go.</p>
</div><?php /**PATH /home/clutch/public_build/resources/views/user/onboarding/introduction.blade.php ENDPATH**/ ?>