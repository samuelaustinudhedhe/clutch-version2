<div>
    Welcome to profile 
</div><?php /**PATH /home/clutch/public_build/resources/views/admin/pages/profile.blade.php ENDPATH**/ ?>